Meu Portfólio Pessoal

Bem-vindo ao repositório do meu portfólio! Este projeto foi desenvolvido para apresentar minha trajetória profissional, meus projetos e minha evolução no mundo da tecnologia. 


Sobre o Projeto

Como estudante de Engenharia de Software com forte vivência na área analítica, decidi construir este espaço do zero para aplicar meus conhecimentos em desenvolvimento web. O site foi projetado para ser responsivo, limpo e direto ao ponto, refletindo minha forma de organizar ideias e solucionar problemas.


Tecnologias Utilizadas
HTML5: Estruturação semântica do conteúdo.
CSS3: Estilização, Flexbox para alinhamentos e Media Queries para responsividade (Mobile First).
Bootstrap Icons: Biblioteca de ícones para as seções de habilidades e redes sociais.

Funcionalidades
Design Responsivo: O layout se adapta perfeitamente a computadores, tablets e smartphones.
Seção de Habilidades: Destaque para ferramentas que domino e estou aprimorando (como Python, SQL, Power BI e desenvolvimento web).
Formulário de Contato: Interface desenhada para facilitar a comunicação.
Links Sociais: Acesso rápido ao meu LinkedIn e GitHub.


Autor
Roger Voppe
Estudante de Engenharia de Software
